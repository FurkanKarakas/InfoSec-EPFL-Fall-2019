import requests
import json
from phe import paillier

# get feature vector
message = {
    'email':'serif.serbest@epfl.ch',
}

response = requests.post("http://com402.epfl.ch/hw5/ex3/get_input", json=message)
print(response.status_code, json.loads(response.content))

vector = json.loads(response.content)['x']

# encrypt feature vector
public_key, private_key = paillier.generate_paillier_keypair()
n = public_key.n
encrypted_vector = [public_key.encrypt(x).ciphertext() for x in vector]

# get encrypted prediction
message = {
    'email':'serif.serbest@epfl.ch',
    'pk': n,
    'encrypted_input': encrypted_vector,
    'model': 1
}
response = requests.post(" http://com402.epfl.ch/hw5/ex3/securehealth/prediction_service", json=message)
print(response.status_code, json.loads(response.content))
encrypted_prediction = json.loads(response.content)["encrypted_prediction"]

# decrypt prediction
encrypted_prediction = json.loads(response.content)["encrypted_prediction"]
to_be_decrypted = paillier.EncryptedNumber(public_key=public_key, ciphertext=encrypted_prediction)
prediction = private_key.decrypt(to_be_decrypted)
print("prediction:", prediction)

# get token 1
message = {
    'email':'serif.serbest@epfl.ch',
    'prediction': prediction
}

response = requests.post("http://com402.epfl.ch/hw5/ex3/get_token_1", json=message)
print(response.status_code, json.loads(response.content))

token = json.loads(response.content)['token']
