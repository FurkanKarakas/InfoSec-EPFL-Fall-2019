import requests
import json
from phe import paillier

public_key, private_key = paillier.generate_paillier_keypair()

def get_encrypted_prediction(vector, public_key, private_key):
    # encrypt feature vector
    n = public_key.n
    encrypted_vector = [public_key.encrypt(x).ciphertext() for x in vector]
    
    # get encrypted prediction
    message = {
        'email':'serif.serbest@epfl.ch',
        'pk': n,
        'encrypted_input': encrypted_vector,
        'model': 2
    }
    response = requests.post(" http://com402.epfl.ch/hw5/ex3/securehealth/prediction_service", json=message)
    #print(response.status_code, json.loads(response.content))
    encrypted_prediction = json.loads(response.content)["encrypted_prediction"]
    return encrypted_prediction

def decrypt_prediction(encrypted_prediction):
    to_be_decrypted = paillier.EncryptedNumber(public_key=public_key, ciphertext=encrypted_prediction)
    prediction = private_key.decrypt(to_be_decrypted)
    return prediction

# steal bias
vector = [0]*12
encrypted_prediction = get_encrypted_prediction(vector, public_key, private_key)
bias = decrypt_prediction(encrypted_prediction)

# steal weights
weights = []
for i in range(12):
    vector = [0]*12
    vector[i] = 1
    encrypted_prediction = get_encrypted_prediction(vector, public_key, private_key)
    weights.append(decrypt_prediction(encrypted_prediction) - bias)
    print(vector, weights[i])

# get token 2
message = {
    'email':'serif.serbest@epfl.ch',
    'weights': weights,
    'bias' : bias
}
response = requests.post(" http://com402.epfl.ch/hw5/ex3/get_token_2", json=message)
print(response.status_code, json.loads(response.content))

token = json.loads(response.content)['token']


