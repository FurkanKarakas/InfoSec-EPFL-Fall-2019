This archive contains:

ex1.py, ex2.py, ex3a.py, ex3b.py as source codes of question 1, 2, 3-a, and 3-b, respectively.
tokens.txt as a list of tokens for each question.
