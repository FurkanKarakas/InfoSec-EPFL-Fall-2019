import wave

song = wave.open("serif.serbest@epfl.ch.wav", mode='rb')
# Convert audio to byte array
frame_bytes = bytearray(list(song.readframes(song.getnframes())))

# Extract the LSB of first of each two bytes
lsb_list = [frame_bytes[i] & 1 for i in range(0, len(frame_bytes), 2)]

# Convert byte array back to string
string = "".join(chr(int("".join(map(str,lsb_list[i:i+8])),2)) for i in range(0,len(lsb_list),8))
song.close()

# Search the hidden message in the string

start = string.find("COM402")
end = string.find("}")

print("hidden message: ", string[start:end + 1])
