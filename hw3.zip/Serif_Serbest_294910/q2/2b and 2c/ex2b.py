import hashlib
from itertools import product

lines = [line.rstrip('\n') for line in open('hw3_ex2.txt')]
hashed_passwords = lines[12:22]

with open("rockyou.txt", errors = 'ignore') as f:
    content = f.readlines()

content = [x.strip() for x in content]

def createcombinations(word):
    chars = [False, True]
    combinations = []
    comb = word
    to_attempt = product(chars, repeat=4)
    for attempt in to_attempt:
        boolarr = list(attempt)
        if boolarr[0]:
            comb = comb.title()
        if boolarr[1]:
            comb = comb.replace("e", "3")
        if boolarr[2]:
            comb = comb.replace("o", "0")
        if boolarr[3]:
            comb = comb.replace("i", "1")
        combinations.append(comb)
    return list(set(combinations))

def find(content, hashed_passwords):
    dic = {}
    list_of_combinations = [createcombinations(word) for word in content]
    generator = [(pwd, hashlib.sha256(pwd.encode()).hexdigest()) for combinations in list_of_combinations for pwd in combinations]
    
    for pwd, hashed in generator:
        if hashed in hashed_passwords:
            dic[pwd] = hashed
            if len(dic) == 10:
                return dic
    return dic

result = find(dic, characters, hashed_passwords)

for key in result:
    print(key)
