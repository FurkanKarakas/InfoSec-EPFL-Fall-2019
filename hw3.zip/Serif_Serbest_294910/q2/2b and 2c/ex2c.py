import hashlib

lines = [line.rstrip('\n') for line in open('hw3_ex2.txt')]
hashed_passwords = []

for line in lines[23:]:
    salt, hashed_password = line.split(", ")
    hashed_passwords.append((salt, hashed_password))
#hashed_passwords

with open("rockyou.txt", errors = 'ignore') as f:
    content = f.readlines()

content = [x.strip() for x in content]

def find(content, hashed_passwords):
    dic = {}
    for salt, hashed_password in hashed_passwords:
        for word in content:
            pwd = word + salt
            hashed = hashlib.sha256(pwd.encode()).hexdigest()
            if hashed == hashed_password:
                dic[word] = hashed
                if len(dic) == 10:
                    return dic
    return dic

result = find(dic, characters, hashed_passwords)

for key in result:
    print(key)
