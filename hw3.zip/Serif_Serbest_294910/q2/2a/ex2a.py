import hashlib

lines = [line.rstrip('\n') for line in open('hw3_ex2.txt')]
hashed_passwords = set(lines[1:11])

# Create alphabet list of lowercase letters
alphabet = []
for letter in range(97,123):
    alphabet.append(chr(letter))

# create list of numbers
numbers = ["0", "1", "2", "3", "4", "5", "6", "7" ,"8", "9"]

characters = alphabet + numbers

#characters

dic = {}

def check (pwd, dic, hashed_passwords):
    hashed = hashlib.sha256(pwd.encode()).hexdigest()
    if hashed in hashed_passwords:
        dic[pwd] = hashed
    return len(dic) == 10
    
def find(dic, characters, hashed_passwords):
    count = 0
    for c1 in characters:
        for c2 in characters:
            for c3 in characters:
                for c4 in characters:
                    pwd = c1 + c2 + c3 + c4
                    if check (pwd, dic, hashed_passwords):
                        return dic
                    for c5 in characters:
                        pwd = c1 + c2 + c3 + c4 + c5
                        if check(pwd, dic, hashed_passwords):
                            return dic
                        for c6 in characters:
                            count += 1
                            if not count % 100000000:
                                print(count / 100000000)
                            pwd = c1 + c2 + c3 + c4 + c5 + c6
                            if check(pwd, dic, hashed_passwords):
                                return dic

result = find(dic, characters, hashed_passwords)

for key in result:
    print(key)
