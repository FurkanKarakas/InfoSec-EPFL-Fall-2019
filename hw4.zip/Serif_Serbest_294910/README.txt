This archive contains:

ex1.py, ex2.py, ex3.py, ex4.conf as source codes of answer.
tokens.txt as a list of tokens for each questions.
