import sys
import logging
logging.basicConfig(stream=sys.stderr, level=logging.DEBUG)

from flask import Flask, request, Response
import bcrypt
import json
import base64
app = Flask(__name__)



@app.route('/')
def hello_world():
    return 'Hello, World!'

@app.route('/hw4/ex2', methods=['POST'])
def ex2():
        
    dic = request.get_json()
        
    user = dic['user']
    pwd = dic['pass']
    pwd_encoded = pwd.encode()

    pwd_hashed = bcrypt.hashpw(pwd_encoded, bcrypt.gensalt())
    
    response = Response(pwd_hashed, status=200)
        
    return response
   

if __name__ == '__main__':
    try:
        app.run(debug=True)
        print('testing', file=sys.stderr)

    except Exception as e: 
        logging.exception(e)
